//////////////////////////////////////////////////////////////
// From JAVA PROGRAMMING: FROM THE BEGINNING, by K. N. King //
// Copyright (c) 2000 W. W. Norton & Company, Inc.          //
// All rights reserved.                                     //
// This program may be freely distributed for class use,    //
// provided that this copyright notice is retained.         //
//                                                          //
// Lottery.java (Chapter 2, page 41)                        //
//////////////////////////////////////////////////////////////

// Displays the winning lottery number

public class Lottery {
  public static void main(String[] args) {
    int winningNumber = 973;
    System.out.print("The winning number ");
    System.out.print("in today's lottery is ");
    System.out.println(winningNumber);
  }
}
