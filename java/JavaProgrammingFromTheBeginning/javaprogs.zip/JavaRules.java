//////////////////////////////////////////////////////////////
// From JAVA PROGRAMMING: FROM THE BEGINNING, by K. N. King //
// Copyright (c) 2000 W. W. Norton & Company, Inc.          //
// All rights reserved.                                     //
// This program may be freely distributed for class use,    //
// provided that this copyright notice is retained.         //
//                                                          //
// JavaRules.java (Chapter 2, page 28)                      //
//////////////////////////////////////////////////////////////

// Displays the message "Java rules!"

public class JavaRules {
  public static void main(String[] args) {
    System.out.println("Java rules!");
  }
}
