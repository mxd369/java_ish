
public final class Test {

    public static void main(String[] args) {
        String[] lines = StdIn.readAllLines();
        for (int i = 0; i < lines.length; i++)
            StdOut.println(lines[i]);
    }

}