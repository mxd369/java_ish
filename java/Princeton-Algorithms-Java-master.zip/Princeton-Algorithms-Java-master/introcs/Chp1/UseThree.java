//1.1.5
public class UseThree {
  public static void main(String[] args) {
    String output = String.format("Hi %s, %s, and %s.", args[2], args[1], args[0]);
    System.out.println(output);
  }
}